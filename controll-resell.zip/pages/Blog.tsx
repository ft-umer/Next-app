import Link from "next/link"

const Blogs = () => {
    return(
        <><h1>Blogs</h1>
        <Link href="/">
        Home
        </Link></>
    )
}

export default Blogs